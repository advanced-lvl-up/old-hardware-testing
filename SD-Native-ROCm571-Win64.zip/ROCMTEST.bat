set TENSILE_LOG_LEVEL=DEBUG
set ROCBLAS_LAYER=4
sdcpp -m ./sd15.safetensors  --cfg-scale 7 --steps 12 -H 256 -W 256 --clip-on-cpu --vae-on-cpu -s -1 -t 0 --rng std_default -v -o example.png -p "closeup watercolor painting, lovely lady with umbrella, artistic, masterpiece"